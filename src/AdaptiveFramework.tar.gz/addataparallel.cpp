#include "addataparallel.h"

AdDataParallel::AdDataParallel()
{
}
