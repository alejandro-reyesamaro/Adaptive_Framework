#ifndef BENCHMARK_H
#define BENCHMARK_H

/**
 * Adaptive search C++
 *
 * \file benchmark.h
 * \brief Benchmark mother class
 * \author Florian Richoux, Alejandro Reyes
 * \date 2014-07-10
 */

#include "strategycost.h"
#include "strategycostswap.h"
#include "strategydisplaysolution.h"
#include "strategyexecuteswap.h"
#include "strategynext_i.h"
#include "strategynext_j.h"
#include "strategyreset.h"

#include <memory>

using namespace std;

/*!
 * \class Benchmark benchmark.h
 * \brief Benchmark mother class
 */
class Benchmark
{
    public:
        shared_ptr<StrategyCost> st_cost;                   //!< Stragety to compute the projected cost on a variable
        shared_ptr<StrategyCostSwap> st_cost_swap;          //!< Stragety to compute the cost of a swap.
        shared_ptr<StrategyDisplaySolution> st_disp_sol;    //!< Stragety to display the solution
        shared_ptr<StrategyExecuteSwap> st_exec_swap;       //!< Stragety to execute a swap
        shared_ptr<StrategyNext_I> st_nextI;                //!< Stragety to return the next i (variable) to consider
        shared_ptr<StrategyNext_J> st_nextJ;                //!< Stragety to return the next j (value) to consider, given i (variable)
        shared_ptr<StrategyReset> st_reset;                 //!< Stragety to perform a reset

        //! The unique constructor for Benchmark
        Benchmark();
};

#endif // BENCHMARK_H
