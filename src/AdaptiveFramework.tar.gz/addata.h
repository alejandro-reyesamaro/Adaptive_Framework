#ifndef ADDATA_H
#define ADDATA_H

/**
 * Adaptive search C++
 *
 * \file addata.h
 * \brief Main data structure
 * \author Florian Richoux, Alejandro Reyes
 * \date 2014-07-10
 */

/*!
 * \class AdData addata.h
 * \brief Main data structure
 */
class AdData
{
    public:
        //! The unique constructor for AdData
        AdData();
};

#endif // ADDATA_H
