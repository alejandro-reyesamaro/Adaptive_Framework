#ifndef STRATEGYCOSTSWAP_H
#define STRATEGYCOSTSWAP_H

/**
 * Adaptive search C++
 *
 * \file strategycostswap.h
 * \brief Strategy Pattern to compute the cost of a swap
 * \author Florian Richoux, Alejandro
 * \date 2014-07-10
 */

/*!
 * \class StrategyCostSwap strategycostswap.h
 * \brief Strategy Pattern to compute the cost of a swap
 */
class StrategyCostSwap
{
    public:
        //! Compute the cost of the swap.
        /*!
        * \param currentCost: the current cost when this function is called.
        *		i and j, the variables with which we simulate a swap to compute the resulting cost.
        * \return The cost if we swap variables i and j.
        */
        virtual int costIfSwap() = 0;
};

#endif // STRATEGYCOSTSWAP_H
