#include "addata.h"

AdData::AdData()
{
}
