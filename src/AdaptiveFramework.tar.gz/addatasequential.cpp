#include "addatasequential.h"

AdDataSequential::AdDataSequential()
{
}
