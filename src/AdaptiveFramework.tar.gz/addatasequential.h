#ifndef ADDATASEQUENTIAL_H
#define ADDATASEQUENTIAL_H

/**
 * Adaptive search C++
 *
 * \file addatasequential.h
 * \brief Main data structure containing sequential concerning information
 * \author Florian Richoux, Alejandro Reyes
 * \date 2014-07-10
 */

#include "addata.h"

/*!
 * \class AdDataSequential addatasequential.h
 * \brief Main data structure containing sequential concerning information
 */
class AdDataSequential : public AdData
{    
    public:
        //! The unique constructor for AdDataParallel
        AdDataSequential();
};

#endif // ADDATASEQUENTIAL_H
