#ifndef ADDATAPARALLEL_H
#define ADDATAPARALLEL_H

/**
 * Adaptive search C++
 *
 * \file addataparallel.h
 * \brief Main data structure containing parallel concerning information
 * \author Florian Richoux, Alejandro Reyes
 * \date 2014-07-10
 */

#include "addata.h"

/*!
 * \class AdDataParallel addataparallel.h
 * \brief Main data structure containing parallel concerning information
 */
class AdDataParallel : public AdData
{
    public:
        //! The unique constructor for AdDataParallel
        AdDataParallel();
};

#endif // ADDATAPARALLEL_H
