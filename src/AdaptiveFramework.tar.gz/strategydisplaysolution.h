#ifndef STRATEGYDISPLAYSOLUTION_H
#define STRATEGYDISPLAYSOLUTION_H

/**
 * Adaptive search C++
 *
 * \file strategydisplaysolution.h
 * \brief Strategy Pattern to display the solution
 * \author Florian Richoux, Alejandro
 * \date 2014-07-10
 */

#include "addata.h"

#include <memory>

/*!
 * \class StrategyDisplaySolution strategydisplaysolution.h
 * \brief Strategy Pattern to display the solution
 */
class StrategyDisplaySolution
{
    public:
        //! Display the solution
        /*!
        * \param p_ad Pointer toward the current configuration (or solution).
        */
        virtual void displaySolution(std::shared_ptr<AdData> data) = 0;
};

#endif // STRATEGYDISPLAYSOLUTION_H
