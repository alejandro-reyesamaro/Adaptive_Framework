#ifndef STRATEGYRESET_H
#define STRATEGYRESET_H

/**
 * Adaptive search C++
 *
 * \file strategyreset.h
 * \brief Strategy Pattern to perform a reset
 * \author Florian Richoux, Alejandro
 * \date 2014-07-10
 */

#include "addata.h"

#include <memory>

/*!
 * \class StrategyReset strategyreset.h
 * \brief Strategy Pattern to perform a reset
 */

class StrategyReset
{
    public:
        //! Perform a reset
        /*!
        * \param n number of reset loop to perform.
        * \param p_ad pointer toward the configuration.
        * \return The new cost, or -1 if unknown.
        */
        virtual int reset(int n, std::shared_ptr<AdData> data) = 0;
};

#endif // STRATEGYRESET_H
