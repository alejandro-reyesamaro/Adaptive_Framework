#include "benchmark.h"

Benchmark::Benchmark()
{
}
