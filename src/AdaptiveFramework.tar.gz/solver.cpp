#include "solver.h"

Solver::Solver()
{
    this->data = this->factoryAdData();
}
